I ran a number of tests with different organizations, block sizes, and caches sizes. My results are below

>./csim 256 4 16 write-allocate write-through lru < gcc.trace  
Total loads: 318197  
Total stores: 197486  
Load hits: 314798  
Load misses: 3399  
>Store hits: 188250  
>Store misses: 9236  
>Total cycles: 25318283  

>./csim 256 4 16 write-allocate write-through fifo < gcc.trace  
Total loads: 318197  
Total stores: 197486  
Load hits: 314171  
Load misses: 4026  
Store hits: 188047  
Store misses: 9439  
Total cycles: 25650283  

>./csim 256 16 16 write-allocate write-through lru < gcc.trace  
 Total loads: 318197  
 Total stores: 197486  
 Load hits: 315548  
 Load misses: 2649  
 Store hits: 188565  
 Store misses: 8921  
 Total cycles: 24892283  

>./csim 256 16 16 write-allocate write-through fifo < gcc.trace  
 Total loads: 318197  
 Total stores: 197486  
 Load hits: 315382  
 Load misses: 2815  
 Store hits: 188508  
 Store misses: 8978  
 Total cycles: 24981483  

>./csim 256 16 16 no-write-allocate write-through lru < gcc.trace  
 Total loads: 318197  
 Total stores: 197486  
 Load hits: 312143  
 Load misses: 6054  
 Store hits: 165208  
 Store misses: 32278  
 Total cycles: 22653605  

>./csim 256 16 16 no-write-allocate write-through fifo < gcc.trace  
 Total loads: 318197  
 Total stores: 197486  
 Load hits: 312004  
 Load misses: 6193  
 Store hits: 165121  
 Store misses: 32365  
 Total cycles: 22709118  

>./csim 512 64 16 write-allocate write-through lru < gcc.trace  
 Total loads: 318197  
 Total stores: 197486  
 Load hits: 315855  
 Load misses: 2342  
 Store hits: 188617  
 Store misses: 8869  
 Total cycles: 24748683  


Through this testing, I noticed that in almost every case, LRU resulted in more hits and less cycles.
 I also noticed that increasing the set size/block amount only really yielded positive results below 256 sets with 16 blocks each.
  We notice that when I increase the sets from 256 to 512, and blocks from 16 to 64, 
  the cycles increased by about 2 million. Even though the amount of hits went up, the 
  miss penalty was much greater. I also observed that the lowest amount of cycles was 
  with 256 sets 16 blocks, and 16 bytes per block. This gave only slightly smaller hits rates than its closest competitors and 
  offered significantly less cycles. LRU was the superior option in basically every simulation I ran however it is worth noting that
  gcc.trace could have more duplicate memory accesses and thus these results can vary depending on the number
  of repeat accesses. Therefore, I believe a cache with 256 sets, 16 blocks with 16 bytes each, and an LRU organization is the best way
  to maximize hits while minimizing miss penalty and lowering cycles.
  
  I did not have a partner for this project and thus did all of the work myself.


